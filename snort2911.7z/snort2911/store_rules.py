import os
import sys
import re
import pymysql
import requests
from bs4 import BeautifulSoup
import time
import xlrd
import xlwt




list_path = "rules/"
rules = ".rules"


#snort log class (struct)
class SnortLog:
	action = ''
	protocol =''
	src_addr = ''
	src_port = ''
	dest_addr = ''
	dest_port = ''
	msg = ''
	flow =''
	detection = ''
	metadata = ''
	refer = ''
	classification = ''
	sid = ''
	rev = ''
	def __init__(self):
		pass
	def print_log(self):
		print("action: " + self.action + "\nprotocol: " + self.protocol + " \nsrc_addr: " + self.src_addr  + "\nsrc_port: " + self.src_port  + "\ndest_addr: " + self.dest_addr  + "\ndest_port: " + self.dest_port 
		 + "\nmsg: " + self.msg  + "\nflow: " + self.flow + " \ndetection: "+ self.detection  + "\nmetadata: " + self.metadata  + "\nrefer: " + self.refer  + "\ncalssification: " + self.classification  + "\nsid: " + self.sid + "\nrev: " + self.rev + "\n\n" )


def format_log_new(line_content):
	header_pos = line_content.find("(")
	
	content_list = line_content[:header_pos]
	

	
	header_list = content_list.split(r"\ ")
	snortlog = SnortLog()

	if content_list[1] == "#":
		
		snortlog.action = header_list[1]
		snortlog.protocol = header_list[2]
		snortlog.src_addr = header_list[3]
		snortlog.src_port = header_list[4]
		snortlog.dest_addr = header_list[6]
		snortlog.dest_port = header_list[7]
	else:
		
		snortlog.action = header_list[0]
		snortlog.protocol = header_list[1]
		snortlog.src_addr = header_list[2]
		snortlog.src_port = header_list[3]
		snortlog.dest_addr = header_list[5]
		snortlog.dest_port = header_list[6]
	
	body_content = line_content[header_pos + 1: ]
	end_pos = body_content.find(";")

	snortlog.msg = body_content[5:end_pos-1]
	
	

	body_content = body_content[end_pos + 2:]
	
	end_pos = body_content.find(r"\;")	
	snortlog.flow = body_content[1:end_pos+2]
	body_content = body_content[end_pos + 2:]
	
	start_pos = body_content.find(r"reference")	

	if start_pos > 0:
		end_pos = body_content.find(r"classtype")
		snortlog.refer = body_content[start_pos:end_pos]
		body_content = body_content[end_pos:]
		

	
	start_pos = body_content.find(r"classtype")	
	
	end_pos = 	body_content[start_pos: ].find(r"\;")
	snortlog.classification = body_content[start_pos+11: end_pos ].replace("\\","")
	
	body_content = body_content[end_pos:]
	
	
	

	start_pos = body_content.find(r" sid\:")
	
	end_pos = body_content[start_pos:].find(r"\;")
	
	snortlog.sid = body_content[start_pos + 6: start_pos + end_pos]
	#print(snortlog.sid)
	body_content = body_content[start_pos + end_pos :]
	start_pos = body_content.find(r"rev\:")
	end_pos = body_content[start_pos:].find(r"\;")
	snortlog.rev = body_content[start_pos + 5: start_pos + end_pos]
	

	return snortlog





def list_rules_file(list_path, rules):
	file_list = os.listdir(list_path)
	rules_list = []
	for index in file_list:
		if os.path.splitext(index)[1]==rules:
			rules_list.append(index)
	return rules_list

def mutiple_test(filename, table_name, workbook):

	count = 0
	sheet = workbook.add_sheet(table_name)

	with open(filename, "r") as hfile:
		#print("read file")
		line_content = re.escape(hfile.readline())
		if len(line_content) > 6:
				
			while line_content:
				
				if line_content[1:5] == r"#\ a" or line_content[1:5] == r"lert":
					
					content = format_log_new(line_content)
					sheet.write(count, 0, int(content.sid))
					sheet.write(count, 1, content.msg.replace("\\", "")[1:-1])
					sheet.write(count, 2, content.refer.replace("\\", ""))
					sheet.write(count, 3, content.classification.replace("\\", ""))
					count = count + 1
					#database_op(content, table_name)
				else:
					print(filename)
					print(line_content)
				line_content = re.escape(hfile.readline())
		hfile.close()
def main():
	#filename = "snort3-community-rules/temp.ruls"

	rule_list = list_rules_file(list_path, rules)
	workbook = xlwt.Workbook()
	for index in rule_list:
		filename = os.path.join(list_path, index)
		table_name = index.split(".")[0].replace('-', '_')
		
		mutiple_test(filename, table_name, workbook)
	workbook.save("snort.xls")	



if __name__ == '__main__':
	main()


